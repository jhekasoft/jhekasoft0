//---------------------------------------------------------------------------

#include <vcl.h>
#include <Mmsystem.h>
#pragma hdrstop

#include "UntMain.h"
#include "ABOUT.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TFrmMain *FrmMain;
int Chislo = 0;
int BeenChisla[89];
int NumHod = 0;

//---------------------------------------------------------------------------
void RndChislo() //��������� ���������� ���������������� �����
{
  int i;

  Chislo = Random(90) + 1;

  for(i=0; i<NumHod; i++)
  {
    if(Chislo == BeenChisla[i])
    {
      RndChislo();
      return;
    }
  }

  if(NumHod <= 88)
  {
    BeenChisla[NumHod] = Chislo;
  }
  NumHod++;
}
//---------------------------------------------------------------------------
__fastcall TFrmMain::TFrmMain(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TFrmMain::BtnRndClick(TObject *Sender)
{
  if(NumHod < 90)
  {
    RndChislo();
    LblNumHod->Caption = IntToStr(NumHod);
    LblNum->Caption = IntToStr(Chislo);
    MmChisla->Text = MmChisla->Text + IntToStr(Chislo) + "; ";
    sndPlaySound("loto.wav", SND_ASYNC);
  }
}
//---------------------------------------------------------------------------
void __fastcall TFrmMain::FormCreate(TObject *Sender)
{
  DoubleBuffered = true;

  Randomize();
}
//---------------------------------------------------------------------------
void __fastcall TFrmMain::FormResize(TObject *Sender)
{
  Panel1->Left = ClientWidth / 2 - Panel1->Width / 2;
  Panel1->Top = ClientHeight / 2 - Panel1->Height / 2;  
}
//---------------------------------------------------------------------------
void __fastcall TFrmMain::BtBtnAboutClick(TObject *Sender)
{
  AboutBox->Show();  
}
//---------------------------------------------------------------------------

