//---------------------------------------------------------------------------

#ifndef UntMainH
#define UntMainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <XPMan.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TFrmMain : public TForm
{
__published:	// IDE-managed Components
  TLabel *LblNum;
  TButton *BtnRnd;
  TLabel *LblNumHod;
  TLabel *Label1;
  TMemo *MmChisla;
  TXPManifest *XPManifest1;
  TImage *Image1;
  TLabel *Label2;
  TPanel *Panel1;
  TBitBtn *BtBtnAbout;
  void __fastcall BtnRndClick(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall FormResize(TObject *Sender);
  void __fastcall BtBtnAboutClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TFrmMain(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TFrmMain *FrmMain;
//---------------------------------------------------------------------------
#endif
